		<!-- Footer -->
		<footer class="footer">
			<p>&copy; fajar & gilang </p>
			<p>projek pkl smkn 1 semparuk</p>

		</footer>