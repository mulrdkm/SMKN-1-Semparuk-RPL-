		<!-- Footer -->
		<footer class="footer">
			<p>&copy;projek pkl</p>
			<p>smkn 1 semparuk</p>

		</footer>