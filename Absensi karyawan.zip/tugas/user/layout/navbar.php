<!-- CONTENT -->
<section id="content">
	<!-- NAVBAR -->
	<nav class="navbar1">
		<i class='bx bx-menu'></i>

		<a href="#" class="brand">
			<img class="logo" src="../../assets/telkom.png" width="25" height="25" alt="telkom">
			<span class="text">Telkom</span>
			<p>Akses</p>
		</a>


		</a>
	</nav>
	<!-- NAVBAR -->