import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewMain {
    public static void main(String[] args) {
        // Membuat frame
        JFrame frame = new JFrame("JComboBox ke JTextArea");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        
        // Mengatur layout
        frame.setLayout(new BorderLayout());

        // Membuat JComboBox dengan beberapa item
        String[] items = {"Pilih Item", "Item 1", "Item 2", "Item 3"};
        JComboBox<String> comboBox = new JComboBox<>(items);

        // Membuat JTextArea
        JTextArea textArea = new JTextArea();
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false); // tidak bisa diedit oleh pengguna

        // Menambahkan ActionListener pada JComboBox
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedItem = (String) comboBox.getSelectedItem();
                textArea.setText("Anda memilih: " + selectedItem);
            }
        });

        // Menambahkan komponen ke frame
        frame.add(comboBox, BorderLayout.NORTH);
        frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

        // Menampilkan frame
        frame.setVisible(true);
    }
}
