<?php
$conn = new mysqli("localhost", "root", "", "buku_tamu");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Menangani permintaan hapus
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $conn->real_escape_string($_POST['delete_id']);
    $sql_delete = "DELETE FROM tamu WHERE id = '$delete_id'";
    $conn->query($sql_delete);
}

// Menangani penambahan tamu
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_id'])) {
    $Nama = $conn->real_escape_string($_POST['nama']);
    $Alamat = $conn->real_escape_string($_POST['alamat']);
    $Tujuan = $conn->real_escape_string($_POST['tujuan']);

    $sql = "INSERT INTO Tamu (Nama, Alamat, Tujuan) VALUES ('$Nama', '$Alamat', '$Tujuan')";
    $conn->query($sql);
}

$result = $conn->query("SELECT * FROM Tamu");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Selamat Datang Di Buku Tamu</title>
</head>
<body>
    <div class="container">
        <h1>Selamat Datang Di Buku Tamu</h1>
        <form method="POST">
            <label>Nama:</label>
            <input type="text" name="nama" required>
            <label>Alamat:</label>
            <input type="text" name="alamat" required>
            <label>Tujuan:</label>
            <input type="text" name="tujuan" required>
            <input type="submit" value="Tambah Tamu">
        </form>

        <table>
            <tr>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Tujuan</th>
                <th>Aksi</th> <!-- Tambahkan kolom untuk aksi -->
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['Nama']) ?></td>
                <td><?= htmlspecialchars($row['Alamat']) ?></td>
                <td><?= htmlspecialchars($row['Tujuan']) ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="delete_id" value="<?= $row['id'] ?>">
                        <input type="submit" value="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus?');">
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <?php $conn->close(); ?>
</body>
</html>