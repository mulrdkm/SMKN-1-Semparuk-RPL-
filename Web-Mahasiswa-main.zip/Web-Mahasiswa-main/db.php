<?php
$koneksi =mysqli_connect('localhost','root','','sukuna');
if(!$koneksi) {
	echo 'sip';




}
?>