<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contoh Halaman</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;

        }

        .footer12 {
        	
            margin-top: auto;
        }
    </style>
</head>
<body>

    <footer class="footer12">
        <div class="container">
            <p class="text-center">Project PKL Siswa RPL | RIQI | SMKN 1 Semparuk</p>
        </div>
    </footer>

    <script type="text/javascript" src="../asset/js/bootstrap.min.js"></script>
</body>
</html>
