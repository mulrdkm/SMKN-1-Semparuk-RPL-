let idSurat = 1;

function tambahSurat(event) {
    event.preventDefault();

    const noSurat = document.getElementById('noSurat').value;
    const tanggalSurat = document.getElementById('tanggalSurat').value;
    const pengirim = document.getElementById('pengirim').value;
    const perihal = document.getElementById('perihal').value;

    const surat = {
        id: idSurat,
        noSurat,
        tanggalSurat,
        pengirim,
        perihal
    };

    suratMasuk.push(surat);
    idSurat++;
    tampilkanAgenda();
    document.getElementById('formSurat').reset();
}

function tampilkanAgenda() {
    const tableBody = document.getElementById('agendaSuratMasuk').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = ''; // Clear table before updating

    suratMasuk.forEach((surat, index) => {
        const row = tableBody.insertRow();
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${surat.noSurat}</td>
            <td>${surat.tanggalSurat}</td>
            <td>${surat.pengirim}</td>
            <td>${surat.perihal}</td>
            <td><button class="delete" onclick="hapusSurat(${surat.id})">Hapus</button></td>
        `;
    });
}

function hapusSurat(id) {
    suratMasuk = suratMasuk.filter(surat => surat.id !== id);
    tampilkanAgenda();
}