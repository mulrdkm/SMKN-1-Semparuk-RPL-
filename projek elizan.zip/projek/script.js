// Fungsi untuk menyimpan daftar tugas ke localStorage
function saveTasks(tasks) {
    // Mengonversi array tugas ke format string (JSON) dan menyimpannya ke localStorage
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Fungsi untuk memuat tugas yang sudah disimpan dari localStorage
function loadTasks() {
    // Mengambil data tugas dari localStorage dan mengonversinya kembali menjadi array
    // Jika tidak ada tugas yang disimpan, maka akan mengembalikan array kosong
    const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    return tasks;
}

// Fungsi untuk menambahkan tugas baru
function addTask() {
    const taskInput = document.getElementById('taskInput');  // Menangkap input tugas
    const taskName = taskInput.value.trim();  // Mengambil nilai input dan menghapus spasi di awal dan akhir

    // Memeriksa apakah input tugas tidak kosong
    if (taskName) {
        const tasks = loadTasks();  // Memuat tugas yang sudah ada
        const newTask = { name: taskName, completed: false };  // Membuat objek tugas baru
        tasks.push(newTask);  // Menambahkan tugas baru ke dalam array tugas
        saveTasks(tasks);  // Menyimpan tugas yang sudah diperbarui ke localStorage
        taskInput.value = '';  // Mengosongkan kolom input
        renderTasks();  // Menampilkan tugas yang telah diperbarui
    }
}

// Fungsi untuk menandai tugas sebagai selesai atau belum selesai
function completeTask(index) {
    const tasks = loadTasks();  // Memuat tugas yang sudah ada
    tasks[index].completed = !tasks[index].completed;  // Membalikkan status selesai tugas
    saveTasks(tasks);  // Menyimpan perubahan status ke localStorage
    renderTasks();  // Menampilkan tugas yang telah diperbarui
}

// Fungsi untuk menghapus tugas
function deleteTask(index) {
    const tasks = loadTasks();  // Memuat tugas yang sudah ada
    tasks.splice(index, 1);  // Menghapus tugas berdasarkan index
    saveTasks(tasks);  // Menyimpan daftar tugas yang telah diperbarui ke localStorage
    renderTasks();  // Menampilkan tugas yang telah diperbarui
}

// Fungsi untuk menampilkan tugas-tugas di UI
function renderTasks() {
    const taskList = document.getElementById('taskList');  // Menangkap elemen <ul> untuk daftar tugas
    taskList.innerHTML = '';  // Menghapus daftar tugas yang lama sebelum memperbarui

    const tasks = loadTasks();  // Memuat tugas yang sudah ada
    tasks.forEach((task, index) => {
        const li = document.createElement('li');  // Membuat elemen <li> baru untuk setiap tugas
        li.className = task.completed ? 'completed' : '';  // Menambahkan kelas "completed" jika tugas selesai

        const taskText = document.createElement('span');  // Membuat elemen <span> untuk nama tugas
        taskText.textContent = task.name;  // Menetapkan nama tugas

        const completeButton = document.createElement('button');  // Tombol untuk menandai tugas selesai/belum selesai
        completeButton.textContent = task.completed ? 'Tandai Belum Selesai' : 'Tandai Selesai';  // Ubah teks tombol
        completeButton.onclick = () => completeTask(index);  // Menambahkan event untuk menandai selesai

        const deleteButton = document.createElement('button');  // Tombol untuk menghapus tugas
        deleteButton.textContent = 'Hapus';  // Teks tombol hapus
        deleteButton.onclick = () => deleteTask(index);  // Menambahkan event untuk menghapus tugas

        li.appendChild(taskText);  // Menambahkan teks tugas ke dalam <li>
        li.appendChild(completeButton);  // Menambahkan tombol selesai ke dalam <li>
        li.appendChild(deleteButton);  // Menambahkan tombol hapus ke dalam <li>
        taskList.appendChild(li);  // Menambahkan elemen <li> ke dalam daftar tugas
    });
}
