<?php
require_once("../../config.php");


$query_mutasi = "SELECT COUNT(*) AS total_mutasi FROM mutasi_siswa";
$result_mutasi = mysqli_query($connection, $query_mutasi);
$data_mutasi = mysqli_fetch_assoc($result_mutasi);
$total_mutasi = $data_mutasi['total_mutasi'];


$query_prestasi = "SELECT COUNT(*) AS total_prestasi FROM prestasi_siswa";
$result_prestasi = mysqli_query($connection, $query_prestasi);
$data_prestasi = mysqli_fetch_assoc($result_prestasi);
$total_prestasi = $data_prestasi['total_prestasi'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Home</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
        }

        .container {
            padding: 20px;
        }

        .card {
            background: #fff;
            margin: 20px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .card h1 {
            font-size: 36px;
            margin: 0;
            color: #333;
        }

        .card p {
            margin: 10px 0;
            font-size: 18px;
            color: #777;
        }

        .card-mutasi {
            border-left: 3px solid #007bff;
        }

        .card-prestasi {
            border-left: 3px solid #007bff;
        }

        .grid {
            display: flex;
            gap: 20px;
            justify-content: center;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #ff4c4c;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn:hover {
            background: #e04343;
        }
    </style>
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="container">
            <div class="head-title">
                <div class="left">
                    <h1>Rekap Siswa</h1>
                </div>
            </div>
            <div class="grid">

                <div class="card card-mutasi">
                    <h3>Siswa Mutasi</h3>
                    <h1><?= $total_mutasi ?></h1>
                    <p>Total Mutasi Siswa</p>
                    <a href="../mutasi/rekap_mutasi.php" class="btn">Lihat Detail</a>
                </div>

                <div class="card card-prestasi">
                    <h3>Siswa Prestasi</h3>
                    <h1><?= $total_prestasi ?></h1>
                    <p>Total Prestasi Siswa</p>
                    <a href="../prestasi/rekap_prestasi.php" class="btn">Lihat Detail</a>
                </div>
            </div>
        </div>
    </main>
</body>

</html>