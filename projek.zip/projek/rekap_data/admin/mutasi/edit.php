<?php
require_once("../../config.php");

$id = $_GET['id'];
$query = "SELECT * FROM mutasi_siswa WHERE id = $id";
$result = mysqli_query($connection, $query);
$data = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_siswa = $_POST['nama_siswa'];
    $kelas_awal = $_POST['kelas_awal'];
    $kelas_tujuan = $_POST['kelas_tujuan'];
    $tanggal_mutasi = $_POST['tanggal_mutasi'];
    $alasan = $_POST['alasan'];

    $update_query = "UPDATE mutasi_siswa SET nama_siswa='$nama_siswa', kelas_awal='$kelas_awal', kelas_tujuan='$kelas_tujuan', tanggal_mutasi='$tanggal_mutasi', alasan='$alasan' WHERE id=$id";
    if (mysqli_query($connection, $update_query)) {
        header("Location: rekap_mutasi.php");
    } else {
        echo "Gagal mengubah data.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Mutasi</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">
            <h1>Edit Mutasi Siswa</h1>
        </div>
        <div class="input-mode">
            <div class="form-container">
                <form method="POST">
                    <label>Nama Siswa</label>
                    <input type="text" name="nama_siswa" value="<?= $data['nama_siswa']; ?>" required>
                    <label>Kelas Awal</label>
                    <input type="text" name="kelas_awal" value="<?= $data['kelas_awal']; ?>" required>
                    <label>Kelas Tujuan</label>
                    <input type="text" name="kelas_tujuan" value="<?= $data['kelas_tujuan']; ?>" required>
                    <label>Tanggal Mutasi</label>
                    <input type="date" name="tanggal_mutasi" value="<?= $data['tanggal_mutasi']; ?>" required>
                    <label>Alasan</label>
                    <textarea name="alasan" required><?= $data['alasan']; ?></textarea>
                    <button type="submit">Simpan</button>
                </form>
            </div>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>