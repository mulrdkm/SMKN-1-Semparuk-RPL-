<?php
require_once("../../config.php");

// Set header untuk file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=rekap_mutasi_siswa.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Query untuk mengambil data dari tabel `mutasi_siswa`
$result = mysqli_query($connection, "SELECT * FROM mutasi_siswa ORDER BY tanggal_mutasi DESC");

// Buat header tabel Excel
echo "<table border='1'>";
echo "<tr><th colspan='6'>REKAP MUTASI SISWA</th> </tr>";
echo "<tr>";
echo "<th>No</th>";
echo "<th>Nama Siswa</th>";
echo "<th>Sekolah Awal</th>";
echo "<th>Sekolah Tujuan</th>";
echo "<th>Tanggal Mutasi</th>";
echo "<th>Alasan</th>";
echo "</tr>";

// Isi data dari database ke dalam tabel
if ($result->num_rows > 0) {
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $no++ . "</td>";
        echo "<td>" . $row['nama_siswa'] . "</td>";
        echo "<td>" . $row['kelas_awal'] . "</td>";
        echo "<td>" . $row['kelas_tujuan'] . "</td>";
        echo "<td>" . $row['tanggal_mutasi'] . "</td>";
        echo "<td>" . $row['alasan'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>Data tidak ditemukan.</td></tr>";
}

echo "</table>";
