<?php
require_once("../../config.php");

$id = $_GET['id'];
$query = "DELETE FROM mutasi_siswa WHERE id = $id";

if (mysqli_query($connection, $query)) {
    header("Location: rekap_mutasi.php");
} else {
    echo "Gagal menghapus data.";
}
