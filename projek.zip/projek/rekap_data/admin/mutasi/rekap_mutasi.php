<?php
require_once("../../config.php");
$result = mysqli_query($connection, "SELECT * FROM mutasi_siswa ORDER BY tanggal_mutasi DESC")
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Mutasi Siswa</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">
            <div class="left">
                <h1>Rekap Mutasi</h1>
            </div>
        </div>
        <a href="tambah_mutasi.php" class="btn-edit">Tanbah data </span></a>
        <a href="export_excel.php" class="btn-export">Ekspor ke Excel</a>
        <div class="table-data">
            <div class="order">
                <div class="head">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Siswa</th>
                                <th>Sekolah Awal</th>
                                <th>Sekolah Tujuan</th>
                                <th>Tanggal Mutasi</th>
                                <th>Alasan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                $no = 1;
                                while ($row = mysqli_fetch_array($result)) : ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $row['nama_siswa'] ?></td>
                                        <td><?= $row['kelas_awal'] ?></td>
                                        <td><?= $row['kelas_tujuan'] ?></td>
                                        <td><?= $row['tanggal_mutasi'] ?></td>
                                        <td><?= $row['alasan'] ?></td>
                                        <td class="text-center">
                                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn-edit">Edit</a>
                                            <a href="hapus.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')" class=" btn-delete">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endwhile ?>

                            <?php } else { ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>