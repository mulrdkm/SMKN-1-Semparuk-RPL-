<?php
require_once("../../config.php");

// Proses data saat form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_siswa = $_POST['nama_siswa'];
    $kelas_awal = $_POST['kelas_awal'];
    $kelas_tujuan = $_POST['kelas_tujuan'];
    $tanggal_mutasi = $_POST['tanggal_mutasi'];
    $alasan = $_POST['alasan'];

    // Query untuk menambahkan data
    $query = "INSERT INTO mutasi_siswa (nama_siswa, kelas_awal, kelas_tujuan, tanggal_mutasi, alasan) 
              VALUES ('$nama_siswa', '$kelas_awal', '$kelas_tujuan', '$tanggal_mutasi', '$alasan')";

    if (mysqli_query($connection, $query)) {
        // Redirect kembali ke halaman utama
        header("Location: rekap_mutasi.php");
        exit();
    } else {
        echo "Gagal menambahkan data: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Mutasi</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">
            <h1>Tambah Data Mutasi</h1>
        </div>
        <div class="input-mode">
            <form action="" method="POST">
                <div class="form-container">
                    <label for="nama_siswa">Nama Siswa:</label>
                    <input type="text" id="nama_siswa" name="nama_siswa" required>

                    <label for="kelas_awal">Sekolah Awal:</label>
                    <input type="text" id="kelas_awal" name="kelas_awal" required>

                    <label for="kelas_tujuan">Sekolah Tujuan:</label>
                    <input type="text" id="kelas_tujuan" name="kelas_tujuan" required>

                    <label for="tanggal_mutasi">Tanggal Mutasi:</label>
                    <input type="date" id="tanggal_mutasi" name="tanggal_mutasi" required>

                    <label for="alasan">Alasan Mutasi:</label>
                    <textarea id="alasan" name="alasan" required></textarea>

                    <button type="submit" class="btn-edit">Simpan</button>
                </div>
            </form>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>