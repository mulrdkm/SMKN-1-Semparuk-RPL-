<?php
require_once("../../config.php");

$id = $_GET['id'];
$query = "SELECT * FROM prestasi_siswa WHERE id = $id";
$result = mysqli_query($connection, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['submit'])) {
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $prestasi = $_POST['prestasi'];
    $tanggal = $_POST['tanggal'];

    $update_query = "UPDATE prestasi_siswa SET nama_siswa='$nama_siswa', kelas='$kelas', prestasi='$prestasi', tanggal='$tanggal' WHERE id=$id";
    if (mysqli_query($connection, $update_query)) {
        header("Location: rekap_prestasi.php");
    } else {
        echo "Gagal mengubah data!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Prestasi Siswa</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">
            <h1>Edit Mutasi Siswa</h1>
        </div>
        <div class="input-mode">
            <div class="form-container">
                <form method="POST" action="">
                    <label>Nama Siswa</label>
                    <input type="text" name="nama_siswa" value="<?= $data['nama_siswa'] ?>" required>
                    <label>Kelas</label>
                    <input type="text" name="kelas" value="<?= $data['kelas'] ?>" required>
                    <label>Prestasi</label>
                    <input type="text" name="prestasi" value="<?= $data['prestasi'] ?>" required>
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>" required>
                    <button type="submit" name="submit">Simpan</button>
                </form>
            </div>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>