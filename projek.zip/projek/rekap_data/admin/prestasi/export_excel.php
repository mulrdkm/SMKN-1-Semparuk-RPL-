<?php
require_once("../../config.php");

// Set header untuk file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=rekap_prestasi_siswa.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Ambil data dari database
$result = mysqli_query($connection, "SELECT * FROM prestasi_siswa ORDER BY tanggal DESC");

// Buat header tabel untuk Excel
echo "<table border='1'>";
echo "<tr><th colspan='5'>REKAP MUTASI SISWA</th> </tr>";
echo "<tr>";
echo "<th>No</th>";
echo "<th>Nama Siswa</th>";
echo "<th>Kelas</th>";
echo "<th>Prestasi</th>";
echo "<th>Tanggal</th>";
echo "</tr>";

// Isi data tabel dari database
if ($result->num_rows > 0) {
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $no++ . "</td>";
        echo "<td>" . $row['nama_siswa'] . "</td>";
        echo "<td>" . $row['kelas'] . "</td>";
        echo "<td>" . $row['prestasi'] . "</td>";
        echo "<td>" . $row['tanggal'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5'>Data tidak ditemukan.</td></tr>";
}

echo "</table>";
