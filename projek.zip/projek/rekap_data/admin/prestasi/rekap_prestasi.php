<?php
require_once("../../config.php");
$result = mysqli_query($connection, "SELECT * FROM prestasi_siswa ORDER BY tanggal DESC")
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Prestasi Siswa</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">

</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>

    <main>
        <div class="head-title">
            <div class="left">
                <h1>Rekap Prestasi Sisiwa</h1>
            </div>
        </div>
        <a href="export_excel.php" class="btn-export">Ekspor ke Excel</a>
        <a href="tambah.php" class="btn-edit">Tanbah data </span></a>
        <div class="table-data">
            <div class="order">
                <div class="head">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                                <th>Prestasi</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                $no = 1;
                                while ($row = mysqli_fetch_array($result)) : ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $row['nama_siswa'] ?></td>
                                        <td><?= $row['kelas'] ?></td>
                                        <td><?= $row['prestasi'] ?></td>
                                        <td><?= $row['tanggal'] ?></td>
                                        <td>
                                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn-edit">Edit</a>
                                            <a href="hapus.php?id=<?= $row['id'] ?>" class="btn-delete" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endwhile ?>
                            <?php } else { ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>