<?php
require_once("../../config.php");

if (isset($_POST['submit'])) {
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $prestasi = $_POST['prestasi'];
    $tanggal = $_POST['tanggal'];

    $query = "INSERT INTO prestasi_siswa (nama_siswa, kelas, prestasi, tanggal) VALUES ('$nama_siswa', '$kelas', '$prestasi', '$tanggal')";
    if (mysqli_query($connection, $query)) {
        header("Location: rekap_prestasi.php");
    } else {
        echo "Gagal menambahkan data!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Prestasi Siswa</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="../home/home.php">Home</a>
            <a href="../../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">

            <h1>Tambah Mutasi Siswa</h1>

        </div>
        <div class="input-mode">
            <div class="form-container">
                <form method="POST" action="">
                    <label>Nama Siswa</label>
                    <input type="text" name="nama_siswa" required>
                    <label>Kelas</label>
                    <input type="text" name="kelas" required>
                    <label>Prestasi</label>
                    <input type="text" name="prestasi" required>
                    <label>Tanggal</label>
                    <input type="date" name="tanggal" required>
                    <button type="submit" name="submit">Simpan</button>
                </form>
            </div>
        </div>
    </main>
    <?php include("../../layout/footer.php"); ?>
</body>

</html>