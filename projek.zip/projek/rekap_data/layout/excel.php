<?php
require_once("../../config.php");

// Set headers untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=rekap_siswa.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Query data
$query_mutasi = "SELECT * FROM mutasi_siswa";
$result_mutasi = mysqli_query($connection, $query_mutasi);

$query_prestasi = "SELECT * FROM prestasi_siswa";
$result_prestasi = mysqli_query($connection, $query_prestasi);

// Tulis data ke dalam tabel HTML yang akan diekspor
echo "<table border='1'>";
echo "<tr><th>Jenis</th><th>Nama Siswa</th><th>Keterangan</th></tr>";

// Data Mutasi
while ($row = mysqli_fetch_assoc($result_mutasi)) {
    echo "<tr>";
    echo "<td>Mutasi</td>";
    echo "<td>" . $row['nama_siswa'] . "</td>";
    echo "<td>" . $row['keterangan'] . "</td>";
    echo "</tr>";
}

// Data Prestasi
while ($row = mysqli_fetch_assoc($result_prestasi)) {
    echo "<tr>";
    echo "<td>Prestasi</td>";
    echo "<td>" . $row['nama_siswa'] . "</td>";
    echo "<td>" . $row['keterangan'] . "</td>";
    echo "</tr>";
}

echo "</table>";
