<footer>
    <div class="footer-content">
        <p>Projek PKL Dinas Pendidikan Singkawang</p>
        <p>RPL SMKN 1 Semparuk</p>
    </div>
</footer>