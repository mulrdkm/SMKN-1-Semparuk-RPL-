<header>
    <div class="brand">Sistem Rekap Siswa</div>
    <nav>
        <a href="home.php" class="">Home</a>
        <a href="prestasi.php" class="<?= basename($_SERVER['PHP_SELF']) == 'prestasi.php' ? 'active' : '' ?>">Prestasi</a>
        <a href="mutasi.php" class="<?= basename($_SERVER['PHP_SELF']) == 'mutasi.php' ? 'active' : '' ?>">Mutasi</a>
    </nav>
</header>