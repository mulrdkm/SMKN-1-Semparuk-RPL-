<?php
require_once("../config.php");
session_start();

// Proses login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = md5($_POST['password']); // Pastikan metode hash cocok dengan yang digunakan di database

  // Query untuk mencocokkan username dan password
  $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  $result = mysqli_query($connection, $query);

  if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);

    // Simpan data user ke sesi
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];

    // Arahkan berdasarkan role
    if ($user['role'] === 'admin') {
      header("Location: ../admin/home/home.php");
    } else {
      header("Location: ../user/home.php");
    }
    exit;
  } else {
    $error = "Username atau password salah!";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>login</title>
  <link rel="stylesheet" href="../aseets/css/style.css">
</head>

<body>
  <div class="dispen">
    <img src="../aseets/foto/dispen.png" alt="logo dinas pendidikan">
  </div>
  <div class="login-container">
    <div class="login-box">
      <div class="main">
        <form action="login.php" method="POST">
          <h2>Login</h2>
          <div class="textbox">
            <input type="text" id="username" name="username" placeholder="Username" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
          </div>
          <button class="btn-login" type="submit" name="login">Login</button>
          <div style="margin-top: 8px;">
            <p class="signup-link">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>

</html>