<?php
require_once("../config.php");

// Proses pendaftaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Enkripsi password
    $role = $_POST['role'];

    // Validasi input
    if (empty($username) || empty($password) || empty($role)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        // Periksa apakah username sudah ada
        $query_check = "SELECT * FROM users WHERE username='$username'";
        $result_check = mysqli_query($connection, $query_check);

        if (mysqli_num_rows($result_check) > 0) {
            $error = "Username sudah terdaftar!";
        } else {
            // Tambahkan ke database
            $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
            if (mysqli_query($connection, $query)) {
                $success = "Pendaftaran berhasil! Silakan login.";
                header("Location: login.php"); // Redirect ke halaman login
                exit;
            } else {
                $error = "Terjadi kesalahan saat mendaftar.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="../aseets/css/style.css">
</head>

<body>
    <div class="dispen">
        <img src="../aseets/foto/dispen.png" alt="logo dinas pendidikan">
    </div>
    <div class="login-container">
        <div class="login-box">
            <div class="main">
                <h2>Register</h2>
                <?php if (isset($error)): ?>
                    <p style="color: red;"><?= $error ?></p>
                <?php endif; ?>
                <?php if (isset($success)): ?>
                    <p style="color: green;"><?= $success ?></p>
                <?php endif; ?>
                <form method="POST">
                    <div class="textbox">

                        <input type="text" id="username" name="username" placeholder="Username" required>


                        <input type="password" id="password" name="password" placeholder="Password" required>


                        <select id="role" name="role" required>
                            <option>--Pilih Role--</option>
                            <option value="admin">Admin</option>
                            <option value="user">User</option>
                        </select>
                    </div>

                    <button class="btn-login" type="submit">Register</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>