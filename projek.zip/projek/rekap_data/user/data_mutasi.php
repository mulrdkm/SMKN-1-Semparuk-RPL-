<?php
require_once("../config.php");
$result = mysqli_query($connection, "SELECT * FROM mutasi_siswa ORDER BY tanggal_mutasi DESC")

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Mutasi Siswa</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="home.php">Home</a>
            <a href="../login/login.php">logout</a>
        </nav>
    </header>
    <main>
        <div class="head-title">
            <div class="left">
                <h1>Data Mutasi Siswa</h1>
            </div>
        </div>
        <div class="table-data">
            <div class="order">
                <div class="head">
                    <table>
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Siswa</th>
                                <th>Sekolah Awal</th>
                                <th>Sekolah Tujuan</th>
                                <th>Tanggal Mutasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                $no = 1;
                                while ($row = mysqli_fetch_array($result)) : ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $row['nama_siswa'] ?></td>
                                        <td><?= $row['kelas_awal'] ?></td>
                                        <td><?= $row['kelas_tujuan'] ?></td>
                                        <td><?= $row['tanggal_mutasi'] ?></td>
                                        <td><?= $row['alasan'] ?></td>
                                    </tr>
                                <?php endwhile ?>
                            <?php } else { ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <?php include("../layout/footer.php"); ?>
</body>

</html>