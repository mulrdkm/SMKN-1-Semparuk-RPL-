<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="../../aseets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        .main {
            padding: 20px;
            text-align: center;
        }

        .home-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .menu-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .menu-item {
            text-align: center;
            padding: 20px;
            background: #007bff;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            width: 200px;
            transition: transform 0.2s, background-color 0.2s;
        }

        .menu-item:hover {
            transform: scale(1.05);
            background-color: #0056b3;
        }

        .menu-icon {
            font-size: 40px;
            margin-bottom: 10px;
        }

        .menu-label {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <header>
        <div class="brand">Sistem Rekap Siswa</div>
        <nav>
            <a href="home.php">Home</a>
            <a href="../login/login.php">Logout</a>
        </nav>
    </header>
    <main>
        <div class="home-container">
            <center>
                <h1>Selamat Datang di Sistem Rekap Siswa</h1>
                <p>Pilih salah satu menu berikut untuk melihat data:</p>
            </center>
            <div class="menu-container">
                <a href="data_mutasi.php" class="menu-item">
                    <div class="menu-icon">📂</div>
                    <div class="menu-label">Rekap Mutasi</div>
                </a>
                <a href="data_prestasi.php" class="menu-item">
                    <div class="menu-icon">🏆</div>
                    <div class="menu-label">Rekap Prestasi</div>
                </a>
            </div>
        </div>
    </main>
    <?php include("../layout/footer.php"); ?>
</body>

</html>