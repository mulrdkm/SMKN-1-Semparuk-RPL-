<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = $_POST['description'];
    $date = $_POST['date'];

    // Proses upload gambar
    $image = $_FILES['image'];
    $targetDir = "uploads/";

    // Buat folder jika belum ada
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Tentukan nama file yang unik
    $imageName = time() . "_" . basename($image["name"]);
    $targetFile = $targetDir . $imageName;

    // Pindahkan file ke folder tujuan
    if (move_uploaded_file($image["tmp_name"], $targetFile)) {
        // Jika upload berhasil, simpan data ke database
        $sql = "INSERT INTO activities (description, date, image) VALUES ('$description', '$date', '$imageName')";
        if ($conn->query($sql) === TRUE) {
            header("Location: index.php");
            exit();
        } else {
            $error = "Gagal menyimpan data ke database: " . $conn->error;
        }
    } else {
        $error = "Gagal mengunggah gambar.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kegiatan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>

    <?php include("../layout/header.php"); ?>
    <div class="container mt-4">
        <h1 class="fw-bold">Tambah Kegiatan</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="fw-bold" for="description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="date" class="fw-bold" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="date" name="date" required>
            </div>
            <div class="mb-3">
                <label for="image" class="fw-bold" class="form-label">Unggah Gambar</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="index.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>

</html>