<?php
include '../config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data dari database
    $sql = "SELECT image FROM activities WHERE id = $id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    // Hapus file gambar
    if ($row && file_exists("uploads/" . $row['image'])) {
        unlink("uploads/" . $row['image']);
    }

    $sql = "DELETE FROM activities WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Gagal menghapus data: " . $conn->error;
    }
}
