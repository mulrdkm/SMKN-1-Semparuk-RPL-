<?php
include '../config.php';

// Ambil data berdasarkan ID
$id = $_GET['id'];
$sql = "SELECT * FROM activities WHERE id = $id";
$result = $conn->query($sql);
$activity = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kegiatan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>
    <?php include("../layout/header.php"); ?>
    <div class="container mt-4">
        <h1 class="fw-bold">Detail Kegiatan</h1>
        <?php if ($activity): ?>
            <div class="mb-3">
                <h3 class="fw-bold">Deskripsi:</h3>
                <p><?= htmlspecialchars($activity['description']) ?></p>
            </div>
            <div class="mb-3">
                <h3 class="fw-bold">Tanggal:</h3>
                <p><?= $activity['date'] ?></p>
            </div>
            <div class="mb-3">
                <h3 class="fw-bold">Gambar:</h3>
                <img src="uploads/<?= $activity['image'] ?>" alt="Gambar" class="img-fluid" width="100">
            </div>
        <?php else: ?>
            <p>Kegiatan tidak ditemukan.</p>
        <?php endif; ?>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </div>
</body>

</html>