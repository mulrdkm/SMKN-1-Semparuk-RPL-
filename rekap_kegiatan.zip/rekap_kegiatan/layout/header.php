<header>
    <div class="brand">Rekap Kegiatan Kantor</div>
    <nav>
        <a href="../login/login.php">logout</a>
    </nav>
</header>