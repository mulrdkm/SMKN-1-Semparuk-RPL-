<?php
session_start();
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Ambil data pengguna dari database
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            // Arahkan sesuai role
            if ($user['role'] === 'admin') {
                header("Location: ../admin/index.php");
            } else {
                header("Location: ../user/index.php");
            }
            exit();
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    /* Background halaman */
    body {
        background: url('https://source.unsplash.com/1600x900/?technology,office') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /* Kotak login */
    .login-container {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 40px;
        border-radius: 10px;
        width: 100%;
        max-width: 400px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .login-title {
        text-align: center;
        font-size: 28px;
        font-weight: bold;
        color: #007bff;
    }

    .login-container input {
        border-radius: 5px;
        margin-bottom: 15px;
    }

    .login-container .btn {
        background-color: #007bff;
        color: white;
        border-radius: 5px;
        width: 100%;
        padding: 10px;
    }

    .login-container .btn:hover {
        background-color: #0056b3;
    }

    .footer {
        text-align: center;
        position: fixed;
        bottom: 10px;
        width: 100%;
        color: white;
    }

    .footer a {
        color: white;
        text-decoration: none;
    }

    .alert {
        margin-bottom: 20px;
    }
</style>

<body>

    <?php
    if (isset($_GET['pesan'])) {
        if ($_GET['pesan'] == "belum_login") {
            $message = "Anda belum login.";
        } else if ($_GET['pesan'] == "akses_ditolak") {
            $message = "Silahkan Login Terlebih Dahulu";
        }
    }
    ?>

    <div class="container mt-5">
        <?php if (isset($message)): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        <h2>Login</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <form method="POST" action="login.php">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>

        <div class="text-center mt-3">
            <a href="register.php" class="text-primary">Belum punya akun? Daftar disini</a>
        </div>
    </div>
</body>

</html>