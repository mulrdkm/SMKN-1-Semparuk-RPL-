<?php
include '../config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data berdasarkan ID
    $sql = "SELECT * FROM activities WHERE id = $id";
    $result = $conn->query($sql);
    $activity = $result->fetch_assoc();

    if (!$activity) {
        echo "Data tidak ditemukan!";
        exit();
    }
} else {
    echo "ID tidak diberikan!";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Kegiatan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../asset/css/style.css">
</head>

<body>
    <?php include("../layout/header.php"); ?>
    <div class="container mt-4">
        <h1 class="fw-bold">Detail Kegiatan</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-bold">Deskripsi</h5>
                <input type="text" value="<?= htmlspecialchars($activity['description']) ?>" readonly>

                <h5 class="card-title fw-bold">Tanggal</h5>
                <input type="text" value="<?= $activity['date'] ?>" readonly>

                <h5 class="card-title fw-bold">Gambar</h5>
                <img src="../admin/uploads/<?= $activity['image'] ?>" alt="Gambar" class="img-fluid" style="max-width: 200px;">


            </div>
        </div>
        <a href="index.php" class="btn btn-secondary mt-3">Kembali</a>
    </div>
</body>

</html>